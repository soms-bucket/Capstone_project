export class Maintenance {
    id!: number 
    automobileId!: number; 
    date!: string;
    description!: string;
  }
  