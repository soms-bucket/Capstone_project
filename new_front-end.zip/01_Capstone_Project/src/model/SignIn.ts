export class Signin{
    usernameOrEmail!: string | null | undefined
    password!: string | null | undefined
}