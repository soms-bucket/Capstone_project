import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable, of } from 'rxjs';
import { SignUp } from '../model/SignUp';
//import { CookieService } from 'ngx-cookie-service';       // for CookieService

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  isAuthenticate: boolean = false;
  
  constructor(private http: HttpClient, ) { }
  //private cookieService: CookieService

  apiUrl = "http://localhost:9400/api/auth"

  authenticate(credentials: any){
    return this.http.post(`${this.apiUrl}/signin`,credentials)
    .pipe(
      map((res: any) => {
        // //token generate
        // if (res && res.token) {
        //   this.saveToken(res.token);
        // }
        console.log(res);
        return res;
      })
    );
  }

  newUser(nwuser: SignUp){
    return this.http.post(`${this.apiUrl}/signup`,nwuser)
    .pipe(
      map((res: any) => {
        console.log(res);
        return res;
      })
    );
  }

  logout():  Observable<boolean>{
    this.isAuthenticate = false;
    //this.removeToken();
      return of(this.isAuthenticate);
  }


  // save cookie

  // saveToken(token: string) {
  //   this.cookieService.set('auth_token', token, { expires: 7 }); // Expires in 7 days
  // }

  // getToken() {
  //   return this.cookieService.get('auth_token');
  // }

  // removeToken() {
  //   this.cookieService.delete('auth_token');
  // }

  // isLoggedIn(): boolean {
  //   return !!this.getToken();
  // }

  
}
