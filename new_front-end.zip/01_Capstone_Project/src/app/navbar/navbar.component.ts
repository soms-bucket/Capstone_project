import { Component } from '@angular/core';
import { AuthServiceService } from '../auth-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {

  constructor(private authService:AuthServiceService, private router: Router) {}
  
  isShow = false 
  setShow(): boolean {
    this.isShow = this.authService.isAuthenticate;
    // this.isShow = this.authService.isLoggedIn();
    // console.log("jjjjjjjjjjjjjj")
    // console.log(this.authService.isLoggedIn())
    return this.isShow;
  }

  doLogout() {
    if (confirm("Are you sure?") == true) {
      this.authService.logout();
      this.router.navigate(["/home"]);
      //prompt("Log-Out SuccessFull!")
    }

      
  }
}
