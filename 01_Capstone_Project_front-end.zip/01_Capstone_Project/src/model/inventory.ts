export class Inventory{
    id!: number;
    automobileId!:number;
    quantity!:number;
}