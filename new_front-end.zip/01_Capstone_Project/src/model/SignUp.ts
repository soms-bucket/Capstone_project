export class SignUp{
    name!: string | null | undefined
    username!: string | null | undefined
    email!: string | null | undefined
    password!: string | null | undefined
}