import {
  MatDivider,
  MatDividerModule
} from "./chunk-6O2FA6S7.js";
import "./chunk-WPE3EP3Q.js";
import "./chunk-OO2XAECT.js";
import "./chunk-VWBEYTUU.js";
import "./chunk-RURLEJOV.js";
import "./chunk-QEYWROO2.js";
import "./chunk-YTR4LZ5T.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
