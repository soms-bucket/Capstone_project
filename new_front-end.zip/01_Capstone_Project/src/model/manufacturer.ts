export class  Manufacturer{
    id!: number;
    name!: string;
    country!:string;
  }