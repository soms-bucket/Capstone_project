import { Component } from '@angular/core';
import { AutomobileServiceService } from '../automobile-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ManufacturerServiceService } from '../manufacturer-service.service';

@Component({
  selector: 'app-list-automobile',
  templateUrl: './list-automobile.component.html',
  styleUrl: './list-automobile.component.css'
})
export class ListAutomobileComponent {

  automobileList: any[] = []
  manufactureId: number = 0;

  mList: any[] = []
  mid = 0
  yearList: any = []
  year = 0

  constructor(private automobileSrv: AutomobileServiceService,
    private manufactureSrv: ManufacturerServiceService,
    private router: Router,
    private route: ActivatedRoute
  ) { }


  ngOnInit(): void {
    this.route.paramMap.subscribe((param) => {
      //editt:101 = @Path Varaible
      //this.manufactureId = Number(param.get('id')); // Read the product id from route
      //this.getAutomobileData(this.manufactureId);
      this.manufactureSrv.getAllData().subscribe( data =>{
        this.mList = data
      })
      this.loadAllAutomobileData()
      this.automobileList.forEach(auto => this.yearList.push(auto.year))

    });
  }

  // feign call
  getAutomobileData(id: number) {
    this.manufactureSrv.getAutomobileByManufacture(id).subscribe(data => {
      this.automobileList = data
    })
  }
  callForManufacturer() {
    this.year = 0
    this.getAutomobileData(this.mid)
  }

  reset() { this.loadAllAutomobileData() }
// ______________________________________________________________________

callForYear(){
  this.mid = 0
  this.getAutomobileByYear(this.year)

}

  getAutomobileByYear(year: number){
    this.automobileSrv.getByYear(year).subscribe( data =>{
      this.automobileList = data
    })
  }
  loadAllAutomobileData() {
    this.automobileSrv.getAllAutomobile().subscribe(data => {
      this.automobileList = data
    })
  }
  delete(aId: number) {
    this.automobileSrv.deletebyId(aId).subscribe({
      next: (data) => {
        if(this.mid) this.getAutomobileData(this.mid)
        else if(this.year) this.getAutomobileByYear(this.year)
        else this.loadAllAutomobileData()
      },
      error: (err) => {
        console.log(err);
      }
    })

  }
}
