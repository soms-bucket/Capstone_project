import { Component } from '@angular/core';
import { ManufacturerServiceService } from '../manufacturer-service.service';

@Component({
  selector: 'app-list-manufacturer',
  templateUrl: './list-manufacturer.component.html',
  styleUrl: './list-manufacturer.component.css'
})
export class ListManufacturerComponent {
  manufacturer: any
  
  constructor(private manufacturerService: ManufacturerServiceService) {
    this.getManufacturers()
  }
  getManufacturers(){
    this.manufacturerService.getAllData().subscribe(data => {
      console.log(data);
      this.manufacturer = data;
    })
  }
  delete(id:number){
    this.manufacturerService.deleteById(id).subscribe(data =>{
    this.getManufacturers()

    })

    
  }
}
