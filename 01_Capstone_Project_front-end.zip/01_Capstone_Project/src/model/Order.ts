export class Order{
    id!: number;
    date!: Date;
    customerId!:number;
    automobileId!: number;    
}