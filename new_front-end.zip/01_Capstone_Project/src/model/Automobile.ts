export class Automobile{
    id!: number
    make!: string | null | undefined
    price!: number | null | undefined
    model!: string | null | undefined
    year!: number | null | undefined
    manufacturerId!: number | null | undefined
}