import {
  MatDivider,
  MatDividerModule
} from "./chunk-ZR7DYSWC.js";
import "./chunk-HJ662KFH.js";
import "./chunk-VWBEYTUU.js";
import "./chunk-OO2XAECT.js";
import "./chunk-RURLEJOV.js";
import "./chunk-QEYWROO2.js";
import "./chunk-YTR4LZ5T.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
